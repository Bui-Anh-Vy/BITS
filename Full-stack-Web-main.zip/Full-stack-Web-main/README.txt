----------------------------
Group 17
COSC2430 Web Programming

Full stack web project: Instakilogram
17th May 2022
----------------------------
Team members: 

	•	Bui Anh Vy (s3891641)
	•	Nguyen Tran Minh Khoi (s3880212)
	•	Tran Tan Phat (s3836612)
	•	Vo Nguyen Nhat Kha (s3924422)

-----------------------------

Contribution: 

Front end: 
	Bui Anh Vy (s3891641): 25%
		-UI requirement
		-Header, Footer, Main
		-CSS styling
		-Merging
 
Backend:

	Nguyen Tran Minh Khoi (s3880212): 25%
        -User Register 
        -Login/Logout & My Account
        -Presentation
        -Merging

	Vo Nguyen Nhat Kha (s3924422): 25%
        -View Images 
        -Share Images
        -Merging

	Tran Tan Phat (s3836612): 25%
        -GDPR Compliance 
        -User & Image Management
        -Merging

-------------------------------------------------------------------------------------------

How to run the website
Step 1: Open command/terminal
Step 2: Cd to working directly. Example: "cd /Users/khoinguyen/Downloads/fullstackwebmain"
Step 3: Enter command like: "php -S 127.0.0.1:8000"
Step 4: Enter in the web browser: "http://localhost:8000/login.php"

-------------------------------------------------------------------------------------------

Test account:
Account 1: tester1@gmail.com
Password: Tester1234
Account 2: tester2@gmail.com
Password: Tester5678

-------------------------------------------------------------------------------------------
Admin URL: http://localhost:8000/admin-instakilogram.php
Youtube URL: https://www.youtube.com/watch?v=WnPSq_TIR3Q
Git: https://github.com/Bui-Anh-Vy/Full-stack-Web
