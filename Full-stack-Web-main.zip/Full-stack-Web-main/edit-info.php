<?php

define("DATABASE_FILE", "database/accounts.db");
define("IMAGE_STORAGE", "database/images/");

// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to login page
if (!isset($_SESSION["email"])) {
	header("location: login.php");
	exit;
}

$first_name = $_SESSION["first_name"];
$last_name = $_SESSION["last_name"];
$email = $_SESSION["email"];
$picture = $_SESSION["picture"];

if ($_SERVER["REQUEST_METHOD"] == "POST") {

	// validate names

	$first_name = $_POST["first_name"];

	if (empty($_POST["first_name"])) {
		$first_name_err = "First name is required";
	} elseif (!preg_match("/^[a-zA-Z]{2,20}$/", $first_name)) {
		$first_name_err = "First name must be between 2 and 20 characters long";
	} else {
		$first_name = trim($first_name);
	}

	$last_name = $_POST["last_name"];

	if (empty($last_name)) {
		$last_name_err = "Last name is required";
	} elseif (!preg_match("/^[a-zA-Z]{2,20}$/", $last_name)) {
		$last_name_err = "Last name must be between 2 and 20 characters long";
	} else {
		$last_name = trim($last_name);
	}

	// Validate password

	if (!empty($_POST["password"])) {
		$inputPass = trim($_POST["password"]);

		$len = strlen($inputPass);
		if (!preg_match("#.*^(?=.{8,20})(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).*$#", $inputPass)) {
			$password_err = "Password must have at least 8 characters and at most 20 characters and meet requirements";
		}

		// Validate confirm password

		if (empty($_POST["confirm_password"])) {
			$confirm_password_err = "Please confirm password.";
		} else {
			$confirm_password = trim($_POST["confirm_password"]);
			if (empty($password_err) && ($inputPass != $confirm_password)) {
				$confirm_password_err = "Password did not match.";
			}
		}
	}

	$target_file = $picture;

	// validate upload file
	if (!empty($_FILES["picture"]["name"])) {

		if ($_FILES["picture"]['error'] != 0) {
			$file_err = "File upload failed";
		} else {
			$target_file   = IMAGE_STORAGE . $_FILES["picture"]["name"];
			$imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
			$maxfilesize   = 800000;
			$allowtypes    = array('jpg', 'png', 'jpeg', 'gif');


			if ($_FILES["picture"]["size"] > $maxfilesize) {
				$file_err = "File is too large.";
			} elseif (!in_array($imageFileType, $allowtypes) || !(getimagesize($_FILES["picture"]["tmp_name"]) !== false)) {
				$file_err = "Not an image file";
			} else {
				if (!move_uploaded_file($_FILES["picture"]["tmp_name"], $target_file)) {
					$file_err = "File upload failed";
				}
			}
		}
	}
	// Check input errors before inserting in database
	if (
		empty($first_name_err)
		&& empty($last_name_err)
		&& empty($email_err)
		&& empty($password_err)
		&& empty($confirm_password_err)
		&& empty($file_err)
	) {

		// append given user into json file
		$fileContent = file_get_contents(DATABASE_FILE);
		$users = json_decode($fileContent, true);

		$_SESSION["picture"] = $target_file;
		$_SESSION["first_name"] = $first_name;
		$_SESSION["last_name"] = $last_name;


		foreach ($users as &$user) {
			if ($user['email'] == $email) {
				$user['first_name'] = $first_name;
				$user['last_name'] = $last_name;
				$user['picture'] = $target_file;
				$user['password'] = isset($inputPass)
					? password_hash($inputPass, PASSWORD_DEFAULT)
					: $user['password'];
			}
		}

		$file = fopen(DATABASE_FILE, "w") or die("Unable to open file!");

		fwrite(
			$file,
			json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
		);
		fclose($file);

		$success = true;
	}
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Welcome</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<style>
		body {
			width: 100%;
		}

		table {
			border: black 1px solid;
			border-radius: 5px;
			margin-bottom: 50px;
		}

		td {
			border: black 1px solid;
			padding: 0.5em;
		}

		th {
			background: lightgray;
			border: black 1px solid;
			padding: 0.5em;
		}
	</style>
	<link rel="stylesheet" href="style.css">
	<script src="https://kit.fontawesome.com/f6af0088ad.js" crossorigin="anonymous"></script>
	<script src="cookie-consent.js"></script>
</head>

<body>
	<?php include('./modules/navbar.php') ?>

	<div class="wrapper centered">
		<h1 class="my-5">My Account</h1>
		<?php
				if (isset($success)) {
					echo
					'<div class="alert alert-success" role="alert">
						<i class="bi bi-check-circle"></i>
						New information updated successfully
				  </div>';
				}
				?>
		<div class="layout-horizontal-2">
			<div>
				<?php
				if (isset($_SESSION['picture'])) {
					echo '<img src="' . $_SESSION['picture'] . '" class="img-thumbnail" width="200" height="200">';
				}
				?>

			</div>
			<div>
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" enctype="multipart/form-data">
			<div class="form-group">
				<label>First Name:</label>
				<input type="text" name="first_name" class="form-control <?php echo (!empty($first_name_err)) ? 'is-invalid' : ''; ?>" value="<?php echo isset($first_name) ? $first_name : '' ?>">
				<span class="invalid-feedback"><?php echo $first_name_err; ?></span>
			</div>
			<div class="form-group">
				<label>Last Name:</label>
				<input type="text" name="last_name" class="form-control <?php echo (!empty($last_name_err)) ? 'is-invalid' : ''; ?>" value="<?php echo isset($last_name) ? $last_name : '' ?>">
				<span class="invalid-feedback"><?php echo $last_name_err; ?></span>
			</div>

			<div class="form-group">
				<label>Email:</label>
				<input type="text" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo isset($email) ? $email : '' ?>" disabled>
			</div>
			<div class="form-group">
				<label>Password:</label>
				<input id="pass" type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="">
				<span id="pass-err" class="invalid-feedback"><?php echo $password_err; ?></span>
			</div>
			<div class="form-group">
				<label>Confirm Password:</label>
				<input id="repass" type="password" name="confirm_password" class="form-control" value="">
				<span id="repass-err" class="invalid-feedback"></span>
			</div>

			<div class="form-group">
				<label>Profile Picture:</label>
				<input type="file" name="picture" class="form-control <?php echo (!empty($file_err)) ? 'is-invalid' : ''; ?>">
				<span class="invalid-feedback"><?php echo $file_err; ?></span>
			</div>

			<div class="form-group">
				<input type="submit" class="btn btn-success" value="Update my profile">
				<input type="reset" class="btn btn-secondary ml-2" value="Reset">
			</div>
		</form>

			</div>

		</div>

	</div>

	<?php include('./modules/footer.php') ?>


</body>

</html>