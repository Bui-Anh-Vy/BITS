<footer class="footer">
    <ul class="list">
        <li>
            <a href="/footer/help.php">Help links</a>
        </li>
        <li>
            <a href="/footer/about.php">About</a>
        </li>
        <li>
            <a href="/footer/privacy.php">Privacy</a>
        </li>
        <li>
            <a href="#"><strong>&copy;2022InstaKilogram</strong></a>
        </li>
    </ul>
</footer>