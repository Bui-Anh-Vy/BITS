Nguyen Tan Tan (S3956465): PHP + Javascript (25%)
Nguyen Phu Nhat Nam (S3950664): PHP + Javascript (25%)
Tran Duc Quy (S3912395): CSS + HTML (25%)
Tran Thien Tan (s3864004): CSS + HTML (25%)

We all agree on the contribution percentages. The total percentage is 100%.

There are two ways to start website:
1. Localhost
- Download php
- Open CMD and write "php -S localhost:1111" on the directory that contains index.php (use can change the port 1111 to whatever you want)
- Open browser, type on URL bar: "localhost:1111/index.php"

2. Directly on domain: https://ec0mmerce-project.herokuapp.com/docs/index.php (very unstable because deployers don't support PHP and database directory is out of root directory)

Accounts to use:

- Vendor:
username: Vendor123
password: Vendor123!

- Customer:
username: Shipper123
password: Shipper123!

- Shipper:
username: Shipper123
password: Shipper123!

Video: https://youtu.be/9LT2VbDl8pY

Github: https://github.com/s3950664/ecommerce-website

