<?php


header('Content-Type: image/png');
readfile($_GET['img']);
