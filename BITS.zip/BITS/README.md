---------------------------
Group 7
COSC2634

Web project: Medical app
6th Jan 2023
---------------------------
Group members:

    Bui Anh Vy (s3891641)
    Bui Quang Man (s3891749)
    Luong Dinh Khang (s3930216)
    Nguyen Thanh Tung (s3878646)

---------------------------
Contribution:

Homepage:
     Bui Anh Vy: 25%
        -UI requirement
        -Header, footer
        -Css stying
        -Merging

Calories-of-food page:
    Luong Dinh Khang: 25%
        -UI requirement
        -Css stying
        -Merging

Calories-calculator page
    Nguyen Thanh Tung: 25%
        -Javascript
        -PHP
        -Merging

Look-up-disease page
    Bui Quang Man: 25%
        -UI requirement
        -Css stying
        -Merging

---------------------------------------
Sign-in page
    Username: admin
    Password: Password01

--------------------------
How to run website:
Step 1: Using visual studio code to open folder
Step 2: Open file index.html in folder homepage

---------------------------------------
Git: https://github.com/Bui-Anh-Vy/BITS/tree/main