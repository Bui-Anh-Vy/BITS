const activeButton = document.getElementById("box-active");

activeButton.addEventListener("click", function () {
  activeButton.innerHTML = "Delivered";
});
