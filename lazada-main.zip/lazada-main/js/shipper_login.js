const form = document.getElementById('form');
const username = document.getElementById('username');
const email = document.getElementById('email');
const password = document.getElementById('password');

form.addEventListener('submit', (e) => {
    e.preventDefault();
    checkInputs();
} );

function checkInputs() {
    const usernameValue = username.value.trim();
    const emailValue = email.value.trim();
    const passwordValue = password.value.trim();

// username
    if(usernameValue === ''){
        setErrorFor(username, "username cannot be blank");
    }else{
        setSuccessFor(username);
    }
  // email
  if(emailValue === ''){
        setErrorFor(email, "email cannot be blank");
    } else if(!isEmail(emailValue)) {
        setErrorFor(email, "email is not valid");
    }else {
        setSuccessFor(email);
    } 
    // password
    if(passwordValue === ''){
      setErrorFor(password, "password cannot be blank");
  }
    if (passwordValue.length < 8 || passwordValue.length > 15) {
      setErrorFor(password, "Password length is not good");
      return false;

    }
  
    // Lowercase
    let lowerCase = 'abcdefghijklmnopqrstuvwxyz';
    let found = false;
    for (let i = 0; i < passwordValue.length; i++) {
      let c = passwordValue.charAt(i);
      if (lowerCase.includes(c)) {
        found = true;
        break;
      }
    }
    if (!found) {
      setErrorFor(password, "no lower case letter")
      return false;
    }
  
    // Uppercase
    let upperCase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    found = false;
    for (let i = 0; i < passwordValue.length; i++) {
      let c = passwordValue.charAt(i);
      if (upperCase.includes(c)) {
        found = true;
        break;
      }
    }
    if (!found) {
      setErrorFor(password, "no uppercase letter")
      return false;
    }
  
    // Digit
    let digit = '0123456789';
    found = false;
    for (let i = 0; i < passwordValue.length; i++) {
      let c = passwordValue.charAt(i);
      if (digit.includes(c)) {
        found = true;
        break;
      }
    }
    if (!found) {
      setErrorFor(password, "no digit")
      return false;
    }
    else{
      setSuccessFor(password);
  }
}

function setErrorFor(input, message){
    const formControl = input.parentElement;
    const small = formControl.querySelector('small');

    small.innerText = message;

    formControl.className = 'input_field error';
}

function setSuccessFor(input) {
    const formControl = input.parentElement;
    formControl.className = 'input-field success';
}

function isEmail(email) {
    return /[a-zA-Z0-9]+@([a-zA-Z0-9]+(\.[a-zA-Z0-9]+)*\.[a-zA-Z0-9]+)/.test(email);
}









